#include "ls1x.h"
#include "Config.h"


extern int cmdline();
void main(void)
{
	    cmdline();


}
