/*
        节点二
*/

#include "ls1x.h"
#include "Config.h"
#include "ls1x_latimer.h"
#include "ls1x_gpio.h"
#include "include.h"
#include "ls1x_printf.h"
#include "ls1x_uart.h"
#include "ls1c102_interrupt.h"
#include "ls1c102_i2c.h"
#include "ls1c102_adc.h"
#include "oled96.h"
#include "HX711.h"

char str1[50];   //   温度数据
char str2[50];   //   湿度数据
char str3[50];   //   温度曲线数据
char str4[50];   //   湿度曲线数据
char str5[50];   //   空气质量数据
uint8_t   BEEP_flag1 = 0;
uint8_t   water_flag1 = 0;
uint8_t   bottle_flag1 = 0;
uint8_t   BEEP_flag2 = 0;
uint8_t   water_flag2 = 0;
uint8_t   bottle_flag2 = 0;

//   初始化温度数据
uint16_t Temp;

//   初始化TDS相关参数
int TDS_Vbase = 0;    //   测量电压值
uint16_t Temp2 = 0;   //   修正温度
int TDS_V = 0;  //   温度修正电压
uint16_t TDS =0;

//   初始化水位相关参数
uint16_t baselevel = 11;        //   基础水位数值
uint16_t shuiwei = 0;          //   实时水位
uint16_t level = 0;            //   最终水位

//   初始化PH相关参数
int PH_Vbase = 0;
uint16_t PH =0;

//   初始化浊度相关参数
int ZD_Vbase = 0;
uint16_t ZD =0;

uint32_t weight=0;

int main(int arg, char *args[])
{
    // //   初始化蜂鸣器
    BEEP_Init();

    //   初始化LED
    LED_Init();
    
    // //   语音模块初始化
    ASRO2_Init();

    // //   DS18B20初始化
    DS18B20_Init();

    // //   adc采集初始化
    AFIO_RemapConfig(AFIOB, GPIO_Pin_4, 0);
    Adc_powerOn();//adc电源开启
    Adc_openGroup(ADC_EN_I4 | ADC_EN_I5 | ADC_EN_I6 | ADC_EN_I7);

    //初始化IIC引脚及IIC屏幕    
    gpio_pin_remap(GPIO_PIN_4,GPIO_FUNC_MAIN);//引脚复用4：scl
    gpio_pin_remap(GPIO_PIN_5,GPIO_FUNC_MAIN);//引脚复用5：sda
    I2C_InitTypeDef I2C_InitStruct0;
    I2C_StructInit(&I2C_InitStruct0);
    I2C_Init(I2C, &I2C_InitStruct0);
    OLED_Init();// 初始化 OLED 模块
    OLED_Clear();// OLED 清屏

    OLED_ShowNum(2,2,12,5,16);

    HX711_GPIO_Init();   //³ÆÖØ´«¸ÐÆ÷³õÊ¼»¯
	Get_Tare();

    Init_HX711pin();
	delay_init();

    Get_Maopi();				//称毛皮重量
	delay_ms(2000);
	Get_Maopi();	

    OLED_ShowNum(2,2,12345,5,16);

    if (nbiot_init() != 0) {
        printf("NB-IoT init failed\n");
        return -1;
    }
    
    printf("NB-IoT module initialized\n");
    
    if (nbiot_connect() != 0) {
        printf("Network register failed\n");
        nbiot_cleanup();
        return -1;
    }
    
    printf("Network registered\n");
    
    // 发送CoAP数据到云平台
    const char *data = "{\"temp\":25.6,\"humidity\":60}";
    if (nbiot_send_data("coap://iot.example.com", 5683, "/sensor/data", data) == 0) {
        printf("Data sent successfully\n");
    } else {
        printf("Data send failed\n");
    }
    
    nbiot_cleanup();

    while(1)
    {
        Get_Weight();

        OLED_ShowNum(0,0,Weight_Shiwu,10,16);

        if(Weight_Shiwu>200)
        {
            LED_Open();
        }
        else
        {
            LED_Close();
        }

        OLED_ShowNum(0,0,weight,10,16);
        OLED_ShowNum(2,2,123456,6,16);

        //   获取温度数值
        Temp = DS18B20_GetTemperatureInteger();
        sprintf(str1,"n0.val=%d\xFF\xFF\xFF",Temp);
        puts2(0,str1);
        
        //   获取TDS数值
        TDS_Vbase = Adc_getVoltage(ADC_CHANNEL_I6);
        Temp2 = 1 + 2 * (Temp - 25) / 100;
        TDS_V = TDS_Vbase * Temp2;
        TDS = (67 * TDS_V * TDS_V * TDS_V / 1000 / 1000 / 1000 - 128 * TDS_V * TDS_V / 1000 / 1000 + 429 * TDS_V / 1000 + 200) * 1;
        sprintf(str2,"n4.val=%d\xFF\xFF\xFF",TDS);
        puts2(0,str2);

        //   获取水位数值
        shuiwei = Adc_Measure(ADC_CHANNEL_I4);
        if(shuiwei > 2700)
        {
            level = baselevel+1;
            sprintf(str3,"n1.val=%d\xFF\xFF\xFF",level);
            puts2(0,str3);
        }
        else
        {
            level = baselevel;
            sprintf(str3,"n1.val=%d\xFF\xFF\xFF",level);
            puts2(0,str3);
        }

        //  获取ph值
        PH_Vbase = Adc_getVoltage(ADC_CHANNEL_I7);
        PH = 17-6*PH_Vbase/1000;
        sprintf(str4,"n3.val=%d\xFF\xFF\xFF",PH);
        puts2(0,str4);

        //  获取浊度值
        ZD_Vbase = Adc_getVoltage(ADC_CHANNEL_I5)*5/33*10;
        ZD = (4330-866*ZD_Vbase/1000)/10+20;
        sprintf(str5,"n2.val=%d\xFF\xFF\xFF",ZD);
        puts2(0,str5);
  
        printf("w:%d,t:%d,p:%d,z:%d",level,TDS,PH,ZD);

        flag2_get();
        
        if(BEEP_flag1 || BEEP_flag2)
        {
            BEEP_Open();
        }
        else
        {
            BEEP_Close();
        }
        if(water_flag1 || water_flag2)
        {
            gpio_write_pin(GPIO_PIN_23, 1);
        }
        else
        {
            gpio_write_pin(GPIO_PIN_23, 0);
        }
        if(bottle_flag1 || bottle_flag2)
        {
            gpio_write_pin(GPIO_PIN_22, 1);
        }
        else
        {
            gpio_write_pin(GPIO_PIN_22, 0);
        }


    }
    return 0;
}

