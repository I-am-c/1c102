#ifndef _BEEP_H
#define _BEEP_H

#include "ls1x_gpio.h"
#include "ls1x_latimer.h"   //   使用延时函数

#define   BEEP_Pin   GPIO_PIN_20

void BEEP_Init(void);
void BEEP_Open(void);
void BEEP_Close(void);

#endif
