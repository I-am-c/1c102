/*   
        蜂鸣器相关程序   
*/

#include "BEEP.h"

/*
name：蜂鸣器初始化
function：设置引脚为输出模式，并保持关闭状态
*/
void BEEP_Init(void)
{
    gpio_pin_remap(BEEP_Pin, GPIO_FUNC_GPIO);
    gpio_set_direction(BEEP_Pin, GPIO_Mode_Out); // 配置输出模式
    gpio_write_pin(BEEP_Pin, 1);
}

/*
name：开启蜂鸣器
function：设置引脚为低电平
*/
void BEEP_Open(void)
{
    gpio_write_pin(BEEP_Pin, 0);
}

/*
name：关闭蜂鸣器
function：设置引脚为高电平
*/
void BEEP_Close(void)
{
    gpio_write_pin(BEEP_Pin, 1);
}

