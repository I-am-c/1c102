/*   
        LED相关程序   
*/

#include "LED.h"

/*
name：LED初始化
function：设置引脚为输出模式，并保持关闭状态
*/
void LED_Init(void)
{
    gpio_pin_remap(LED_Pin, GPIO_FUNC_GPIO);
    gpio_set_direction(LED_Pin, GPIO_Mode_Out); // 配置输出模式
    gpio_write_pin(LED_Pin, 0);
}

/*
name：开启LED
function：设置引脚为高电平
*/
void LED_Open(void)
{
    gpio_write_pin(LED_Pin, 1);
}

/*
name：关闭LED
function：设置引脚为低电平
*/
void LED_Close(void)
{
    gpio_write_pin(LED_Pin, 0);
}

