#ifndef _DS18B20_H_
#define _DS18B20_H_

#include "ls1x_gpio.h"
#include "ls1x_latimer.h"

/*  DS18B20引脚定义 */
#define DS18B20_PIN     GPIO_PIN_19

/*    IO操作函数	 */									   
#define	DS18B20_READ    gpio_get_pin(DS18B20_PIN)
#define DS18B20_HIGH 	gpio_write_pin(DS18B20_PIN, 1)
#define DS18B20_LOW     gpio_write_pin(DS18B20_PIN, 0)

uint8_t DS18B20_Init(void);			//初始化DS18B20
void DS18B20_Reset(void);			//复位DS18B20   
uint8_t DS18B20_Check(void);			//检测是否存在DS18B20
void Delay_us(uint8_t t);

uint16_t DS18B20_GetTemperatureInteger(void);	//获取温度
void DS18B20_Start(void);		//开始温度转换
void DS18B20_Write_Byte(uint8_t dat);//写入一个字节
uint8_t DS18B20_Read_Byte(void);		//读出一个字节
uint8_t DS18B20_Read_Bit(void);		//读出一个位

#endif
