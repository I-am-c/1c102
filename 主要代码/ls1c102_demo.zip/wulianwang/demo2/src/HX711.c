#include "HX711.h"

#define MEDIAN_LEN  5  			//ÖÐÖµÂË²¨µÄÂË²¨³¤¶È,Ò»°ãÈ¡ÆæÊý
#define MEDIAN      3  			//ÖÐÖµÔÚÂË²¨Êý×éÖÐµÄÎ»ÖÃ
uint32_t   buffer[MEDIAN_LEN];   	//ÖÐÖµÂË²¨µÄÊý¾Ý»º´æ
int   medleng = 0;          	//Ò»×éÖÐÖµÂË²¨Êý¾ÝÖÐ,½øÈëÂË²¨»º´æµÄÊý¾Ý¸öÊý
uint32_t   xd,xd1;					//Êý¾Ý¶Ô±È´óÐ¡ÖÐ¼ä±äÁ¿

extern uint32_t	weight;		      //Êµ¼ÊÖØÁ¿Öµ
uint32_t	pi_weight;		        //Æ¤ÖØ
//uint32_t	hx711_xishu=31706;		//ÕâÊÇÒ»¸öÐÞÕýÏµÊý£¬ÀýÈç1000gíÀÂë³Æ³öÀ´ÊÇ934g£¬ÔòHX711_xishu=Ô­Êý¾Ý*1000/934;
uint32_t	hx711_xishu=31706;

void HX711_Data_Out(void)
{
    gpio_set_direction(HX711_DATA_PIN,GPIO_Mode_Out);
}

void HX711_Data_In(void)
{
    gpio_set_direction(HX711_DATA_PIN,GPIO_Mode_In);
}

void HX711_SCK_Out(void)
{
    gpio_set_direction(HX711_SCK_PIN,GPIO_Mode_Out);
}

void HX711_SCK_In(void)
{
    gpio_set_direction(HX711_SCK_PIN,GPIO_Mode_In);
}

// void HX711_GPIO_Init(void)
// {
// 	HX711_SCK_Out();
//     HX711_Data_Out();
// }

// uint32_t Read_HX711(void)
// {
// 	uint8_t i;
// 	uint32_t value = 0;
	
// 	/**
// 	Êý¾ÝÊÖ²áÐ´µ½£¬µ±Êý¾ÝÊä³ö¹Ü½Å DOUT Îª¸ßµçÆ½Ê±£¬±íÃ÷A/D ×ª»»Æ÷»¹Î´×¼±¸ºÃÊä³öÊý¾Ý£¬´ËÊ±´®¿ÚÊ±
// 	ÖÓÊäÈëÐÅºÅ PD_SCK Ó¦ÎªµÍµçÆ½£¬ËùÒÔÏÂÃæÉèÖÃÒý½Å×´Ì¬¡£
// 	**/
// 	HX711_Data_Out();
// 	HX711_DATA_HIGH; //³õÊ¼×´Ì¬DTÒý½ÅÎª¸ßµçÆ½
// 	//delay_us(1);
// 	HX711_SCK_LOW; //³õÊ¼×´Ì¬SCKÒý½ÅÎªµÍµçÆ½
// 	HX711_Data_In();
// 	/**
// 	µÈ´ýDTÒý½Å±äÎª¸ßµçÆ½
// 	**/
// 	while(HX711_DATA_READ);
// 	//delay_us(1);
	
// 	/**
// 	µ± DOUT ´Ó¸ßµçÆ½±äµÍµçÆ½ºó£¬PD_SCK Ó¦ÊäÈë 25 ÖÁ 27 ¸ö²»µÈµÄÊ±ÖÓÂö³å
// 	25¸öÊ±ÖÓÂö³å ---> Í¨µÀA ÔöÒæ128
// 	26¸öÊ±ÖÓÂö³å ---> Í¨µÀB ÔöÒæ32
// 	27¸öÊ±ÖÓÂö³å ---> Í¨µÀA ÔöÒæ64
// 	**/
// 	for(i=0; i<24; i++) //24Î»Êä³öÊý¾Ý´Ó×î¸ßÎ»ÖÁ×îµÍÎ»ÖðÎ»Êä³öÍê³É
// 	{
// 		HX711_SCK_HIGH;
// 		//delay_us(1);
// 		HX711_SCK_LOW;
// 		if(HX711_DATA_READ == 0)
// 		{
// 			value = value << 1;
// 			value |= 0x00;
// 		}
// 		if(HX711_DATA_READ == 1)
// 		{
// 			value = value << 1;
// 			value |= 0x01;
// 		}
// 		//delay_us(1);
// 	}
	
// 	//µÚ 25ÖÁ 27 ¸öÊ±ÖÓÂö³åÓÃÀ´Ñ¡ÔñÏÂÒ»´Î A/D ×ª»»µÄÊäÈëÍ¨µÀºÍÔöÒæ
// 	HX711_SCK_HIGH; 
// 	value = value^0x800000; 
// 	delay_us(1); 
// 	HX711_SCK_LOW; 
// 	delay_us(1);  
// 	return value; 	
// }

// void Get_Tare(void)//»ñÈ¡Æ¤ÖØ
// {
// 	uint32_t hx711_dat;
// 	uint8_t i;
// 	for(i=0;i<MEDIAN_LEN;i++)
// 	{
// 		hx711_dat=Read_HX711();	        	//HX711AD×ª»»Êý¾Ý´¦Àí
// 		if(medleng == 0)                    //»º´æµÄµÚ1¸öÔªËØ,Ö±½Ó·ÅÈë,²»ÐèÒªÅÅÐò
// 		{ 
// 			buffer[0] = hx711_dat; medleng = 1; 
// 		}
// 		else                            	//²åÈëÅÅÐòËã·¨,°´´ÓÐ¡µ½´óµÄË³ÐòÅÅÁÐ 
// 		{  
// 			for(i = 0; i < medleng; i ++)  
// 			{
// 				if( buffer[i] > hx711_dat) 	// ÂÖÑ¯µ½µÄµ±Ç°ÔªËØ>ADÖµ,Ôò½»»»ËüÃÇµÄÖµ£¬xdÎªÖÐ¼ä±äÁ¿´æ·ÅÎ»ÖÃ
// 				{ 
// 					xd = hx711_dat; hx711_dat = buffer[i]; buffer[i] = xd;
// 				}
// 			}
// 			buffer[medleng] = hx711_dat; 	//°ÑÂÖÑ¯³ö½Ï´óµÄÊý·ÅÈë»º´æµÄºóÃæ.
// 			medleng++;
// 		}		
// 		if(medleng >= MEDIAN_LEN) 		    //ADC²ÉÑùµÄÊý¾Ý¸öÊý´ïµ½ÖÐÖµÂË²¨ÒªÇóµÄÊý¾Ý¸öÊý
// 		{
// 			hx711_dat = buffer[MEDIAN];	    //×îÖÕÖØÁ¿È¡ÖÐÖµÂË²¨Êý×éµÄÖÐ¼äÖµ
// 			medleng = 0; 
// 		}
// 	}
// 	pi_weight=(uint16_t)(hx711_dat/100);   // hx711_dat/100
// }

// int Get_Weight(void)	  //»ñÈ¡±»²âÎïÌåÖØÁ¿
// {
// 	uint32_t hx711_data,a;
// 	uint32_t get,aa;	
// 	hx711_data=Read_HX711();		   //HX711Êý¾Ý²É¼¯º¯Êý
// 	get=(uint16_t)(hx711_data/100);   //HX711AD×ª»»Êý¾Ý´¦Àí£¬Êý¾ÝËõÐ¡100±¶  hx711_data/100
// 	if(get>pi_weight)
// 	{
// 		a=Read_HX711();			   //ÖØÐÂ²É¼¯HX711Êý¾Ý					 														   
// 		aa=(uint16_t)(a/100)-pi_weight;			     //²âµÃµÄÖØÁ¿Öµ¼õÈ¥Æ¤ÖØ  a/100
// 		weight=(uint16_t)((uint32_t)aa/10*hx711_xishu);//    (uint32_t)aa/100000*hx711_xishu	
// 	}
// 	else
// 	{
// 		weight=0;
// 	}		
// 	return weight;
// }


 
uint32_t HX711_Buffer;
uint32_t Weight_Maopi;
uint32_t Weight_Shiwu;
uint8_t Flag_Error = 0;
 
//校准参数
//因为不同的传感器特性曲线不是很一致，因此，每一个传感器需要矫正这里这个参数才能使测量值很准确。
//当发现测试出来的重量偏大时，增加该数值。
//如果测试出来的重量偏小时，减小改数值。
//该值可以为小数
#define GapValue 106
 
 
void Init_HX711pin(void)
{
	HX711_SCK_Out();
    HX711_Data_Out();
}
 
 
 
//****************************************************
//读取HX711
//****************************************************
uint32_t HX711_Read(void)	//增益128
{
	unsigned long count; 
	unsigned char i; 
  	HX711_DATA_HIGH; 
	//delay_us(1);
  	HX711_SCK_LOW; 
  	count=0; 
  	while(HX711_DATA_READ); 
  	for(i=0;i<24;i++)
	{ 
	  	HX711_SCK_HIGH; 
	  	count=count<<1; 
		//delay_us(1);
		HX711_SCK_LOW; 
	  	if(HX711_DATA_READ)
			count++; 
		//delay_us(1);
	} 
 	HX711_SCK_HIGH; 
    count=count^0x800000;//第25个脉冲下降沿来时，转换数据
	//delay_us(1);
	HX711_SCK_LOW;  
	return(count);
}
 
//****************************************************
//获取毛皮重量
//****************************************************
void Get_Maopi(void)
{
	Weight_Maopi = HX711_Read();	
} 
 
//****************************************************
//称重
//****************************************************
void Get_Weight(void)
{
	HX711_Buffer = HX711_Read();
	if(HX711_Buffer > Weight_Maopi)			
	{
		Weight_Shiwu = HX711_Buffer;
		Weight_Shiwu = Weight_Shiwu - Weight_Maopi;				//获取实物的AD采样数值。
	
		Weight_Shiwu = (uint32_t)((uint32_t)Weight_Shiwu/GapValue); 	//计算实物的实际重量
		Weight_Shiwu = Weight_Shiwu*10/37;
																		//因为不同的传感器特性曲线不一样，因此，每一个传感器需要矫正这里的GapValue这个除数。
																		//当发现测试出来的重量偏大时，增加该数值。
																		//如果测试出来的重量偏小时，减小改数值。
	}
 
	
}




