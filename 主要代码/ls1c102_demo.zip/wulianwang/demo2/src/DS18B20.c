#include "DS18B20.h"

void Delay_us(uint8_t t)
{
  while(t--);
}

/*******************************************************************************
* 函 数 名         : DS18B20_Reset
* 函数功能		     : 复位DS18B20  
* 输    入         : 无
* 输    出         : 无
*******************************************************************************/
void DS18B20_Reset(void)	   
{                 
	// DS18B20_IO_OUT(); //SET PG11 OUTPUT
	DS18B20_LOW;         //拉低DQ
	delay_us(750);       //拉低750us
	DS18B20_HIGH;        //DQ=1 
	delay_us(15);        //15US
}
 
/*******************************************************************************
* 函 数 名         : DS18B20_Check
* 函数功能		     : 检测DS18B20是否存在
* 输    入         : 无
* 输    出         : 1:未检测到DS18B20的存在，0:存在
*******************************************************************************/
uint8_t DS18B20_Check(void) 	   
{   
	uint8_t retry=0;
	// DS18B20_IO_IN();//SET PG11 INPUT	 
	
	while (DS18B20_READ&&retry<200)
	{
		retry++;
		delay_us(1);
	};
	
	if(retry>=200)
		return 1;
	else 
		retry=0;
	
	while (!DS18B20_READ&&retry<240)
	{
		retry++;
		delay_us(1);
	};
	if(retry>=240)
		return 1;	 
	
	return 0;
}
 
/*******************************************************************************
* 函 数 名         : DS18B20_Read_Bit
* 函数功能		     : 从DS18B20读取一个位
* 输    入         : 无
* 输    出         : 1/0
*******************************************************************************/
uint8_t DS18B20_Read_Bit(void) 			 // read one bit
{
	uint8_t data;
	
    DS18B20_LOW;
	// delay_us(1);

	DS18B20_HIGH; 
	// DS18B20_IO_IN();//SET PG11 INPUT
	delay_us(3);
	
	if(DS18B20_READ)
		data=1;
	else 
		data=0;	 
	
	delay_us(50);  
	
	return data;
}
 
/*******************************************************************************
* 函 数 名         : DS18B20_Read_Byte
* 函数功能		     : 从DS18B20读取一个字节
* 输    入         : 无
* 输    出         : 一个字节数据
*******************************************************************************/
uint8_t DS18B20_Read_Byte(void)    // read one byte
{        
	uint8_t i,j,dat;
	dat=0;
		for (i=1;i<=8;i++) 
	{
		j=DS18B20_Read_Bit();
		dat=(j<<7)|(dat>>1);
	}						    
	return dat;
}
 
/*******************************************************************************
* 函 数 名         : DS18B20_Write_Byte
* 函数功能		     : 写一个字节到DS18B20
* 输    入         : dat：要写入的字节
* 输    出         : 无
*******************************************************************************/
void DS18B20_Write_Byte(uint8_t dat)     
{             
	uint8_t j;
	uint8_t testb;
	for (j=1;j<=8;j++) 
	{
		testb=dat&0x01;
		dat=dat>>1;
		if (testb) 
		{
            DS18B20_LOW;
			// delay_us(1);                            
            DS18B20_HIGH;
			delay_us(58);             
		}
		else 
		{
            DS18B20_LOW;
			delay_us(58);             
            DS18B20_HIGH;
			// delay_us(1);                          
		}
	}
}
 
/*******************************************************************************
* 函 数 名         : DS18B20_Start
* 函数功能		     : 开始温度转换
* 输    入         : 无
* 输    出         : 无
*******************************************************************************/
void DS18B20_Start(void)// ds1820 start convert
{   					               
	DS18B20_Reset();	   
	DS18B20_Check();	 
	DS18B20_Write_Byte(0xcc);// skip rom
	DS18B20_Write_Byte(0x44);// convert

	DS18B20_Reset();	   
	DS18B20_Check();	 
	DS18B20_Write_Byte(0xcc);// skip rom
	DS18B20_Write_Byte(0xbe);// convert
} 
 
/*******************************************************************************
* 函 数 名         : DS18B20_Init
* 函数功能		     : 初始化DS18B20的IO口 DQ 同时检测DS的存在
* 输    入         : 无
* 输    出         : 1:不存在，0:存在
*******************************************************************************/   	 
uint8_t DS18B20_Init(void)
{
 	DS18B20_Reset();
	return DS18B20_Check();
}  
 
/*******************************************************************************
* 函 数 名         : DS18B20_GetTemperture
* 函数功能		     : 从ds18b20得到温度值
* 输    入         : 无
* 输    出         : 温度数据
*******************************************************************************/ 
uint16_t DS18B20_GetTemperatureInteger(void)
{
    uint8_t TL, TH;
    uint16_t temp;

    DS18B20_Start();             // DS1820 start convert

    TL = DS18B20_Read_Byte();    // LSB
    TH = DS18B20_Read_Byte();    // MSB
    temp = (TH << 8) + TL;
	// temp = temp << 5;
	// temp = temp*625/10000;
	// temp = (temp << 4) + temp;   // 相当于 temp * 16，即乘以 16
    // temp = (temp + (temp << 3)) >> 14;  // 相当于 temp * 200，然后右移 14 位，即除以 10000
	// temp = temp >> 9;  // Shift right by 4 to discard the fractional bits
	// temp = temp*625/10000;
	if((temp&0xf800)==0x0000)
	{
		
		temp = temp << 5;
		temp = temp >> 9;
		
	}
	
	return temp;

	// if((temp&0xf800)==0xf800)
	// {
	// 	temp=(~temp)+1;
	// 	value=temp*(-0.0625);
	// }
	// else
	// {
	// 	value=temp*0.0625;	
	// }
    // if (TH > 7) {
    //     TH = ~TH;
    //     TL = ~TL;
    //     return 0;  // 温度为负
    // } else {
    //     tem = TH;               // 获取高八位
    //     tem <<= 8;
    //     tem += TL;              // 获取底八位
    //     tem *= 625;             // 转换为带符号的温度值（乘以625，不使用浮点数）
    //     tem /= 10000;            // 将乘以625后的温度值转换为实际温度值
    //     return tem;             // 返回温度值
    // }
}