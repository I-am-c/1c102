#ifndef __HX711_H
#define __HX711_H

#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
 
#define  HX711_DATA_PIN  GPIO_PIN_31       //ÕâÀïÊ¹ÓÃµÄDOUTÒý½ÅÊÇA0
#define  HX711_SCK_PIN   GPIO_PIN_30      //ÕâÀïÊ¹ÓÃµÄSCKÒý½ÅÊÇA1
 

#define HX711_DATA_HIGH gpio_write_pin(HX711_DATA_PIN, 1)
#define HX711_DATA_LOW gpio_write_pin(HX711_DATA_PIN, 0)
#define HX711_SCK_HIGH gpio_write_pin(HX711_SCK_PIN, 1)
#define HX711_SCK_LOW gpio_write_pin(HX711_SCK_PIN, 0)
#define	HX711_DATA_READ    gpio_get_pin(HX711_DATA_PIN)
#define	HX711_SCK_READ    gpio_get_pin(HX711_SCK_PIN)
 
 
void HX711_Data_Out(void);
void HX711_Data_In(void);
void HX711_SCK_Out(void);
void HX711_SCK_In(void);

// void HX711_GPIO_Init(void);
// uint32_t Read_HX711(void);
// void Get_Tare(void);//»ñÈ¡Æ¤ÖØ
// int Get_Weight(void);	  //»ñÈ¡±»²âÎïÌåÖØÁ¿ 


void Init_HX711pin(void);
uint32_t HX711_Read(void);
void Get_Maopi(void);
void Get_Weight(void);

extern uint32_t HX711_Buffer;
extern uint32_t Weight_Maopi;
extern uint32_t Weight_Shiwu;
extern uint8_t Flag_Error;


#endif
 
