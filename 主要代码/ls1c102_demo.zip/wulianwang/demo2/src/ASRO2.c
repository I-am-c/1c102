/*   
        语音模块相关程序   
*/

#include "ASRO2.h"

/*
name：语音模块初始化
function：设置引脚为输入模式，并保持关闭状态
*/
void ASRO2_Init(void)
{
    gpio_pin_remap(BEEP_get_Pin, GPIO_FUNC_GPIO);
    // gpio_write_pin(BEEP_get_Pin, 0);
    gpio_set_direction(BEEP_get_Pin, GPIO_Mode_In); // 配置输入模式
    
    gpio_pin_remap(FAN_get_Pin, GPIO_FUNC_GPIO);
    // gpio_write_pin(FAN_get_Pin, 0);
    gpio_set_direction(FAN_get_Pin, GPIO_Mode_In); // 配置输入模式

    gpio_pin_remap(LED_get_Pin, GPIO_FUNC_GPIO);
    // gpio_write_pin(LED_get_Pin, 0);
    gpio_set_direction(LED_get_Pin, GPIO_Mode_In); // 配置输入模式
}

/*
name：状态获取
function：设置flag2
*/
void flag2_get(void)
{
    if(BEEP_get == 1)
    {
        BEEP_flag2 = 1;
        // BEEP_Open();
    }
    else
    {
        BEEP_flag2 = 0;
        // BEEP_Close();
    }
    if(FAN_get == 1)
    {
        water_flag2 = 1;
        // FAN_Open();
    }
    else
    {
        water_flag2 = 0;
        // FAN_Close();
    }
    if(LED_get == 1)
    {
        bottle_flag2 = 1;
        // LED_Open();
    }
    else
    {
        bottle_flag2 = 0;
        // LED_Close();
    }
}

