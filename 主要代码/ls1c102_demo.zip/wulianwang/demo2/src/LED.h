#ifndef _LED_H
#define _LED_H

#include "ls1x_gpio.h"
#include "ls1x_latimer.h"   //   使用延时函数

#define   LED_Pin   GPIO_PIN_20

void LED_Init(void);
void LED_Open(void);
void LED_Close(void);

#endif
