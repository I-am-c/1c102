/**
 * nbiot_ls1c102.c - 龙芯LS1C102 NB-IoT通信实现
 * 
 * 功能：
 * 1. AT指令基础通信
 * 2. 网络注册管理
 * 3. CoAP协议数据传输
 * 4. 低功耗管理
 */

#include "NBIOT.h"
 
 // 模块配置
 #define NB_IOT_UART_DEV "/dev/ttyS1"  // NB-IoT模块连接的串口设备
 #define UART_BAUDRATE B9600           // 波特率
 #define AT_TIMEOUT_MS 5000            // AT指令超时时间(ms)
 
 // 调试宏
 #define NB_DEBUG 1
 #if NB_DEBUG
 #define nb_debug(fmt, ...) printf("[NB-IoT] " fmt, ##__VA_ARGS__)
 #else
 #define nb_debug(fmt, ...)
 #endif
 
 // NB-IoT模块状态
 typedef enum {
     NB_STATE_INIT = 0,
     NB_STATE_READY,
     NB_STATE_REGISTERING,
     NB_STATE_REGISTERED,
     NB_STATE_CONNECTING,
     NB_STATE_CONNECTED,
     NB_STATE_ERROR
 } nb_state_t;
 
 // NB-IoT上下文结构体
 typedef struct {
     int uart_fd;
     nb_state_t state;
     pthread_mutex_t lock;
     char imei[16];
     char imsi[16];
     char ip_addr[16];
     int signal_strength;
 } nb_context_t;
 
 // 全局上下文
 static nb_context_t nb_ctx;
 
 /**
  * 初始化串口
  */
 static int uart_init(const char *dev, int baudrate) {
     struct termios options;
     int fd = open(dev, O_RDWR | O_NOCTTY | O_NDELAY);
     if (fd < 0) {
         perror("open serial failed");
         return -1;
     }
 
     // 获取当前串口配置
     tcgetattr(fd, &options);
 
     // 设置波特率
     cfsetispeed(&options, baudrate);
     cfsetospeed(&options, baudrate);
 
     // 设置8位数据位，无校验，1位停止位
     options.c_cflag &= ~CSIZE;
     options.c_cflag |= CS8;
     options.c_cflag &= ~PARENB;
     options.c_cflag &= ~CSTOPB;
     options.c_cflag &= ~CRTSCTS;
 
     // 设置原始输入模式
     options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
     options.c_oflag &= ~OPOST;
 
     // 设置超时和最小读取字符数
     options.c_cc[VMIN] = 0;
     options.c_cc[VTIME] = 10; // 1秒超时
 
     // 应用配置
     if (tcsetattr(fd, TCSANOW, &options) != 0) {
         perror("tcsetattr failed");
         close(fd);
         return -1;
     }
 
     tcflush(fd, TCIOFLUSH);
     return fd;
 }
 
 /**
  * 发送AT指令
  */
 static int at_send_command(int fd, const char *cmd, char *resp, size_t resp_len, int timeout_ms) {
     if (fd < 0 || !cmd) return -1;
 
     nb_debug("Send AT: %s\n", cmd);
 
     // 发送命令
     int len = strlen(cmd);
     if (write(fd, cmd, len) != len) {
         perror("write AT command failed");
         return -1;
     }
 
     // 等待响应
     fd_set fds;
     struct timeval tv;
     int ret;
     size_t total = 0;
     time_t start = time(NULL);
 
     while (1) {
         FD_ZERO(&fds);
         FD_SET(fd, &fds);
 
         tv.tv_sec = 0;
         tv.tv_usec = 100000; // 100ms
 
         ret = select(fd + 1, &fds, NULL, NULL, &tv);
         if (ret < 0) {
             perror("select error");
             return -1;
         } else if (ret == 0) {
             // 超时检查
             if (time(NULL) - start > timeout_ms / 1000) {
                 nb_debug("AT command timeout\n");
                 return -1;
             }
             continue;
         }
 
         // 读取数据
         if (FD_ISSET(fd, &fds)) {
             char buf[128];
             int n = read(fd, buf, sizeof(buf) - 1);
             if (n > 0) {
                 buf[n] = '\0';
                 nb_debug("Recv: %s\n", buf);
 
                 if (resp && total + n < resp_len) {
                     memcpy(resp + total, buf, n);
                     total += n;
                 }
 
                 // 检查OK响应
                 if (strstr(buf, "OK")) {
                     if (resp) resp[total] = '\0';
                     return 0;
                 }
 
                 // 检查ERROR响应
                 if (strstr(buf, "ERROR")) {
                     return -1;
                 }
             }
         }
     }
 
     return -1;
 }
 
 /**
  * 初始化NB-IoT模块
  */
 static int nb_init_module(nb_context_t *ctx) {
     char resp[256] = {0};
 
     // 测试AT指令
     if (at_send_command(ctx->uart_fd, "AT\r\n", resp, sizeof(resp), AT_TIMEOUT_MS) != 0) {
         nb_debug("Module not responding\n");
         return -1;
     }
 
     // 关闭回显
     if (at_send_command(ctx->uart_fd, "ATE0\r\n", NULL, 0, AT_TIMEOUT_MS) != 0) {
         nb_debug("Disable echo failed\n");
         return -1;
     }
 
     // 获取IMEI
     if (at_send_command(ctx->uart_fd, "AT+CGSN=1\r\n", resp, sizeof(resp), AT_TIMEOUT_MS) == 0) {
         char *p = strstr(resp, "+CGSN:");
         if (p) {
             sscanf(p, "+CGSN: %15s", ctx->imei);
             nb_debug("IMEI: %s\n", ctx->imei);
         }
     }
 
     // 获取IMSI
     if (at_send_command(ctx->uart_fd, "AT+CIMI\r\n", resp, sizeof(resp), AT_TIMEOUT_MS) == 0) {
         char *p = strstr(resp, "\r\n");
         if (p) {
             sscanf(p + 2, "%15s", ctx->imsi);
             nb_debug("IMSI: %s\n", ctx->imsi);
         }
     }
 
     // 设置APN (根据运营商配置)
     if (at_send_command(ctx->uart_fd, "AT+CGDCONT=1,\"IP\",\"CMNBOT\"\r\n", NULL, 0, AT_TIMEOUT_MS) != 0) {
         nb_debug("Set APN failed\n");
         return -1;
     }
 
     return 0;
 }
 
 /**
  * 注册到网络
  */
 static int nb_register_network(nb_context_t *ctx) {
     char resp[256] = {0};
     int retry = 0;
     
     ctx->state = NB_STATE_REGISTERING;
     
     // 检查网络注册状态
     while (retry++ < 10) {
         if (at_send_command(ctx->uart_fd, "AT+CEREG?\r\n", resp, sizeof(resp), AT_TIMEOUT_MS) == 0) {
             int n, stat;
             if (sscanf(resp, "+CEREG: %d,%d", &n, &stat) == 2) {
                 if (stat == 1 || stat == 5) { // 1: registered, 5: registered roaming
                     ctx->state = NB_STATE_REGISTERED;
                     nb_debug("Network registered\n");
                     
                     // 获取信号强度
                     if (at_send_command(ctx->uart_fd, "AT+CSQ\r\n", resp, sizeof(resp), AT_TIMEOUT_MS) == 0) {
                         int rssi, ber;
                         if (sscanf(resp, "+CSQ: %d,%d", &rssi, &ber) == 2) {
                             ctx->signal_strength = rssi;
                             nb_debug("Signal strength: %d\n", rssi);
                         }
                     }
                     
                     // 获取IP地址
                     if (at_send_command(ctx->uart_fd, "AT+CGPADDR\r\n", resp, sizeof(resp), AT_TIMEOUT_MS) == 0) {
                         char *p = strstr(resp, "+CGPADDR:");
                         if (p) {
                             sscanf(p, "+CGPADDR: %*d,\"%15[^\"]\"", ctx->ip_addr);
                             nb_debug("IP address: %s\n", ctx->ip_addr);
                         }
                     }
                     
                     return 0;
                 }
             }
         }
         sleep(2);
     }
     
     ctx->state = NB_STATE_ERROR;
     return -1;
 }
 
 /**
  * 发送CoAP数据
  */
 int nb_send_coap_data(nb_context_t *ctx, const char *host, int port, const char *uri, const char *data) {
     char cmd[256] = {0};
     char resp[512] = {0};
     
     if (ctx->state != NB_STATE_REGISTERED) {
         nb_debug("Network not ready\n");
         return -1;
     }
     
     // 创建CoAP socket
     if (at_send_command(ctx->uart_fd, "AT+NSOCR=\"DGRAM\",17,0,1\r\n", resp, sizeof(resp), AT_TIMEOUT_MS) != 0) {
         nb_debug("Create socket failed\n");
         return -1;
     }
     
     int socket_id = atoi(resp);
     nb_debug("Created socket: %d\n", socket_id);
     
     // 发送CoAP数据
     snprintf(cmd, sizeof(cmd), "AT+NSOST=%d,\"%s\",%d,%d,\"%.*s\"\r\n", 
              socket_id, host, port, strlen(data), strlen(data), data);
     
     if (at_send_command(ctx->uart_fd, cmd, resp, sizeof(resp), AT_TIMEOUT_MS) != 0) {
         nb_debug("Send data failed\n");
         // 关闭socket
         snprintf(cmd, sizeof(cmd), "AT+NSOCL=%d\r\n", socket_id);
         at_send_command(ctx->uart_fd, cmd, NULL, 0, AT_TIMEOUT_MS);
         return -1;
     }
     
     nb_debug("Data sent successfully\n");
     
     // 关闭socket
     snprintf(cmd, sizeof(cmd), "AT+NSOCL=%d\r\n", socket_id);
     at_send_command(ctx->uart_fd, cmd, NULL, 0, AT_TIMEOUT_MS);
     
     return 0;
 }
 
 /**
  * NB-IoT模块初始化
  */
 int nbiot_init(void) {
     memset(&nb_ctx, 0, sizeof(nb_context_t));
     pthread_mutex_init(&nb_ctx.lock, NULL);
     
     // 初始化UART
     nb_ctx.uart_fd = uart_init(NB_IOT_UART_DEV, UART_BAUDRATE);
     if (nb_ctx.uart_fd < 0) {
         return -1;
     }
     
     // 初始化模块
     if (nb_init_module(&nb_ctx) != 0) {
         close(nb_ctx.uart_fd);
         return -1;
     }
     
     nb_ctx.state = NB_STATE_READY;
     return 0;
 }
 
 /**
  * NB-IoT连接网络
  */
 int nbiot_connect(void) {
     pthread_mutex_lock(&nb_ctx.lock);
     int ret = nb_register_network(&nb_ctx);
     pthread_mutex_unlock(&nb_ctx.lock);
     return ret;
 }
 
 /**
  * 发送数据
  */
 int nbiot_send_data(const char *host, int port, const char *uri, const char *data) {
     pthread_mutex_lock(&nb_ctx.lock);
     int ret = nb_send_coap_data(&nb_ctx, host, port, uri, data);
     pthread_mutex_unlock(&nb_ctx.lock);
     return ret;
 }
 
 /**
  * 获取模块状态
  */
 nb_state_t nbiot_get_state(void) {
     return nb_ctx.state;
 }
 
 /**
  * 清理资源
  */
 void nbiot_cleanup(void) {
     if (nb_ctx.uart_fd >= 0) {
         close(nb_ctx.uart_fd);
         nb_ctx.uart_fd = -1;
     }
     pthread_mutex_destroy(&nb_ctx.lock);
 }
 
 // 示例使用
 int main() {
     if (nbiot_init() != 0) {
         printf("NB-IoT init failed\n");
         return -1;
     }
     
     printf("NB-IoT module initialized\n");
     
     if (nbiot_connect() != 0) {
         printf("Network register failed\n");
         nbiot_cleanup();
         return -1;
     }
     
     printf("Network registered\n");
     
     // 发送CoAP数据到云平台
     const char *data = "{\"temp\":25.6,\"humidity\":60}";
     if (nbiot_send_data("coap://iot.example.com", 5683, "/sensor/data", data) == 0) {
         printf("Data sent successfully\n");
     } else {
         printf("Data send failed\n");
     }
     
     nbiot_cleanup();
     return 0;
 }