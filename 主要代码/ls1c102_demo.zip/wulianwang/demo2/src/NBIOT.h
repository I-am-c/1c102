#ifndef _NBIOT_H
#define _NBIOT_H

 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <unistd.h>
 #include <fcntl.h>
 #include <termios.h>
 #include <sys/select.h>
 #include <time.h>
 #include <pthread.h>
 
 // 模块配置
 #define NB_IOT_UART_DEV "/dev/ttyS1"  // NB-IoT模块连接的串口设备
 #define UART_BAUDRATE B9600           // 波特率
 #define AT_TIMEOUT_MS 5000            // AT指令超时时间(ms)
 
 // 调试宏
 #define NB_DEBUG 1
 #if NB_DEBUG
 #define nb_debug(fmt, ...) printf("[NB-IoT] " fmt, ##__VA_ARGS__)
 #else
 #define nb_debug(fmt, ...)
 #endif
 
 // NB-IoT模块状态
 typedef enum {
     NB_STATE_INIT = 0,
     NB_STATE_READY,
     NB_STATE_REGISTERING,
     NB_STATE_REGISTERED,
     NB_STATE_CONNECTING,
     NB_STATE_CONNECTED,
     NB_STATE_ERROR
 } nb_state_t;
 
 // NB-IoT上下文结构体
 typedef struct {
     int uart_fd;
     nb_state_t state;
     pthread_mutex_t lock;
     char imei[16];
     char imsi[16];
     char ip_addr[16];
     int signal_strength;
 } nb_context_t;
 
 // 全局上下文
 static nb_context_t nb_ctx;=
 static int uart_init(const char *dev, int baudrate);
 static int at_send_command(int fd, const char *cmd, char *resp, size_t resp_len, int timeout_ms) ;
 static int nb_init_module(nb_context_t *ctx) ;
 static int nb_register_network(nb_context_t *ctx);
 int nb_send_coap_data(nb_context_t *ctx, const char *host, int port, const char *uri, const char *data);
 int nbiot_init(void);
 int nbiot_connect(void) ;
 int nbiot_send_data(const char *host, int port, const char *uri, const char *data);
 nb_state_t nbiot_get_state(void);
 void nbiot_cleanup(void);


 endif