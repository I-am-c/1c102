#ifndef _ASRO2_H
#define _ASRO2_H

#include "ls1x_gpio.h"
#include "ls1x_latimer.h"   //   使用延时函数

extern   uint8_t   BEEP_flag2;
extern   uint8_t   water_flag2;
extern   uint8_t   bottle_flag2;

#define   BEEP_get_Pin   GPIO_PIN_24
#define   FAN_get_Pin   GPIO_PIN_25
#define   LED_get_Pin   GPIO_PIN_26
#define   BEEP_get   gpio_get_pin(BEEP_get_Pin)
#define   FAN_get   gpio_get_pin(FAN_get_Pin)
#define   LED_get   gpio_get_pin(LED_get_Pin)

void ASRO2_Init(void);
void flag2_get(void);

#endif
