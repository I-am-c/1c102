from flask import Flask, render_template, request, redirect, url_for, session
from dashscope import Generation
import dashscope

# 设置 API Key
dashscope.api_key = "你的阿里云通义 API Key"
app = Flask(__name__)
app.secret_key = "your_secret_key"  # 设置密钥以支持 session


# 模拟的用户数据（实际应用中可以使用数据库）
valid_username = "1"
valid_password = "1"

def get_water_data_from_aliyun():
    # 模拟阿里云的 REST API 地址和 token
    url = "https://api.aliyun.com/iot/water_quality"
    headers = {
        "Authorization": "Bearer your_token_here"
    }
    try:
        response = requests.get(url, headers=headers, timeout=5)
        if response.status_code == 200:
            return response.json()  # 返回字典结构
        else:
            print("数据请求失败:", response.status_code)
            return None
    except Exception as e:
        print("阿里云连接异常:", e)
        return None
@app.route("/water_data")
def water_data():
    if not session.get("logged_in"):
        return redirect(url_for("login"))

    data = get_water_data_from_aliyun()

    if not data:
        # 模拟数据
        data = {
            "ph": 7.2,
            "temperature": 22.5,
            "tds": 250,
            "turbidity": 3.4,
            "water_level": 120,
            "oxygen": 6.1
        }

    return render_template("water_data.html", data=data)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        # 获取用户输入的用户名和密码
        username = request.form.get("username")
        password = request.form.get("password")

        # 简单的用户名和密码验证
        if username == valid_username and password == valid_password:
            # 登录成功，重定向到设备中心页面
            session["logged_in"] = True
            session["username"] = username
            return redirect(url_for("device_center"))
        else:
            # 登录失败，显示错误消息
            return render_template("login.html", error="用户名或密码错误")

    return render_template("login.html", error=None)

@app.route("/")
def index():
    data = {
        
    }
    return render_template("index.html", data=data)

@app.route("/device")
def device_center():
    devices = [
        {}
    ]
    if not session.get("logged_in"):
        return redirect(url_for("login"))

    return render_template("device.html", devices=devices)

@app.route("/history")
def history():
    # 模拟历史数据列表（可以替换为数据库查询）
    history_data = [
        {}
        # 可继续添加更多数据
    ]
    if not session.get("logged_in"):
        return redirect(url_for("login"))
    return render_template("history.html", history=history_data)



def ask_ai_question(question_text):
    try:
        response = Generation.call(
            model="qwen-plus",  # 或 qwen-turbo
            prompt=question_text,
            temperature=0.7,
            top_p=0.8,
        )
        if response and "output" in response:
            return response["output"]["text"]
        else:
            return "对不起，我暂时无法回答。"
    except Exception as e:
        print("AI调用异常:", e)
        return "AI服务暂时不可用。"
@app.route("/qa", methods=["GET", "POST"])
def qa():
    answer = None
    if request.method == "POST":
        question = request.form.get("question")
        answer = ask_ai_question(question)
    return render_template("qa.html", answer=answer)





if __name__ == "__main__":
    app.run(debug=True)
